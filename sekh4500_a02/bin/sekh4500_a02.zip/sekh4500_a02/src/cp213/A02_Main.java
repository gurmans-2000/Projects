package cp213;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * @author Your name and id here
 * @version 20201-01-29
 */
public class A02_Main {
    // Constants
    public static final String SEP = "-".repeat(40);

    public static void main(String[] args) throws FileNotFoundException  {
    	
    	ArrayList<Food> foods = new ArrayList<Food>();
    	PrintStream ps = new PrintStream("ps.txt");
    	Food f1 = new Food("Vegetable Alicha", 0, false, 20);
    	Food f2 = new Food("Vegetable Alicha", 3, false, 100);
    	f2.write(ps);
    	f1.write(ps);
    	System.out.print(f1.compareTo(f2));
    	
    	PrintStream newfile = new PrintStream("ps.txt");
    	File foodFile = new File("foods.txt");
        Scanner fileReader= new Scanner(foodFile);
        ArrayList<Food> foods1 = FoodUtilities.readFoods(fileReader);
        ArrayList<Food> found_foods = FoodUtilities.foodSearch(foods1, 7, 135, false);
        for (Food food: found_foods) {
        	System.out.print(food);
        	
        }
        FoodUtilities.writeFoods(foods1, newfile);
    
       
    	
   }
}