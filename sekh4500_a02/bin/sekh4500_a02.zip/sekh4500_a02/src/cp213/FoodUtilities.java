package cp213;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Utilities for working with Food objects.
 *
 * @author your name here
 * @version 2021-01-29
 */
public class FoodUtilities {

    /**
     * Determines the average calories in a list of foods. No rounding necessary.
     * Foods list parameter may be empty.
     *
     * @param foods a list of Food
     * @return average calories in all Food objects
     */
    public static int averageCalories(final ArrayList<Food> foods) {
    
	int sum = 0;
	int counter = 0;
	for (Food food : foods) {
		sum =sum + food.getCalories();
		counter += 1;
	}
	return sum/counter;
	
    }

    /**
     * Determines the average calories in a list of foods for a particular origin.
     * No rounding necessary. Foods list parameter may be empty.
     *
     * @param foods  a list of Food
     * @param origin the origin of the Food
     * @return average calories for all Foods of the specified origin
     */
    public static int averageCaloriesByOrigin(final ArrayList<Food> foods, final int origin) {
    	int sum_by_org = 0;
    	int i = 0;
    	for (Food food: foods) {
    		if (food.getOrigin() == origin) {
    			sum_by_org += food.getCalories();
    			i += 1;
    		}
    	}
    	int avg = 0;
    	if (i > 0) {
    		avg = sum_by_org / i;
    	}
    	return avg;
    }

    /**
     * Creates a list of foods by origin.
     *
     * @param foods  a list of Food
     * @param origin a food origin
     * @return a list of Food from origin
     */
    public static ArrayList<Food> getByOrigin(final ArrayList<Food> foods, final int origin) {
    	ArrayList<Food> arlist = new ArrayList<Food>();
    	for (Food food: foods) {
    		if (food.getOrigin() == origin) {
    			arlist.add(food);
    		}
    	}
		return arlist;
    }

    /**
     * Creates a Food object by requesting data from a user. Uses the format:
     * 
     * <pre>
    Name: name
    Origins
     0 Canadian
     1 Chinese
    ...
    11 English
    Origin: origin number
    Vegetarian (Y/N): Y/N
    Calories: calories
     * </pre>
     *
     * @param keyboard a keyboard Scanner
     * @return a Food object
     */
    public static Food getFood(final Scanner keyboard) {
    	System.out.print("Name: ");
    	String name = keyboard.nextLine();
    	System.out.print("Origins\n");
    	System.out.print(Food.originsMenu());
    	System.out.print("Origin Number: ");
    	int origin = keyboard.nextInt();
    	System.out.print("Vegetarian (Y/N): ");
    	char veg = keyboard.next().charAt(0);
    	System.out.print("Calories: ");
    	int cal = keyboard.nextInt();
    	boolean new_veg = false;
    	if (veg == 'Y') {
    		new_veg = true;
    	}
    	Food new_food = new Food(name, origin, new_veg, cal);
    	
		return new_food;
    	
	
    }

    /**
     * Creates a list of vegetarian foods.
     *
     * @param foods a list of Food
     * @return a list of vegetarian Food
     */
    public static ArrayList<Food> getVegetarian(final ArrayList<Food> foods) {
    	ArrayList<Food> veg = new ArrayList<Food>( );
    	for (Food food: foods) {
    		if (food.isVegetarian()) {
    			veg.add(food);
    		}
    	}
    	return veg;
    }

    /**
     * Creates and returns a Food object from a line of string data.
     *
     * @param line a vertical bar-delimited line of food data in the format
     *             name|origin|isVegetarian|calories
     * @return the data from line as a Food object
     */
    public static Food readFood(final String line) {
    	String[] splitted = line.split("\\|");
    	String name_temp = splitted[0];
    	int origin_temp = Integer.parseInt(splitted[1]);
    	boolean veg_temp = Boolean.parseBoolean(splitted[2]);
    	int calories_temp = Integer.parseInt(splitted[3]);
	
    	Food new_food = new Food(name_temp, origin_temp, veg_temp, calories_temp);
	return new_food;
    }

    /**
     * Reads a file of food strings into a list of Food objects.
     *
     * @param fileIn a Scanner of a Food data file in the format
     *               name|origin|isVegetarian|calories
     * @return a list of Food
     */
    public static ArrayList<Food> readFoods(final Scanner fileIn) {
    	String line;
    	Food food;
    	ArrayList<Food> list = new ArrayList<Food>();
    	while ((fileIn.hasNextLine())) {
    		line = fileIn.nextLine();
    		food = readFood(line);
    		list.add(food);
    	       
		
	}
    	return list;
    }

    /**
     * Searches for foods that fit certain conditions.
     *
     * @param foods        a list of Food
     * @param origin       the origin of the food; if -1, accept any origin
     * @param maxCalories  the maximum calories for the food; if 0, accept any
     * @param isVegetarian whether the food is vegetarian or not; if false accept
     *                     any
     * @return a list of foods that fit the conditions specified
     */
    public static ArrayList<Food> foodSearch(final ArrayList<Food> foods, final int origin, final int maxCalories, final boolean isVegetarian) {
    	ArrayList<Food> result = new ArrayList<Food>();
    	
    	for (Food food: foods) {
    		Boolean match_origin;
    		Boolean match_cal;
    		Boolean match_veg;
    		match_origin = food.getOrigin() == origin || origin == -1;
    		match_cal = food.getCalories() <= maxCalories || maxCalories == 0;
    		match_veg = food.isVegetarian() || isVegetarian == false;
    		if (match_origin && match_cal && match_veg) {
    			result.add(food);
    		}
    		
    	}
    	return result;
    }

    /**
     * Writes the contents of a list of Food to a PrintStream.
     *
     * @param foods a list of Food
     * @param ps    the PrintStream to write to
     * @throws FileNotFoundException 
     */
    public static void writeFoods(final ArrayList<Food> foods, PrintStream ps) throws FileNotFoundException {
    	for (Food food : foods) {
    		food.write(ps);
    		}
    }
}